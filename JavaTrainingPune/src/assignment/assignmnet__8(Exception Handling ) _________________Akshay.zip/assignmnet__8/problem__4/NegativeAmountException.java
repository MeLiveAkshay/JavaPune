package assignment.assignmnet__8.problem__4;

public class NegativeAmountException extends Exception{
	public NegativeAmountException(String msg) {
		super(msg);
	}

}
