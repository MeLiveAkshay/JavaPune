package assignment.assignmnet__8.problem__5;

@SuppressWarnings("serial")
public class LowSalException extends Exception
{

	public LowSalException(String msg)
	{
		super(msg);
	}

	
}
