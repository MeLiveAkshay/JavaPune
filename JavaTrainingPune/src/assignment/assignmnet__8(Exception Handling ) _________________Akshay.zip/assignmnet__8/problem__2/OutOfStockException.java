package assignment.assignmnet__8.problem__2;

public class OutOfStockException extends Exception {
	public OutOfStockException(String string)
	{
		super(string);
	}
}
