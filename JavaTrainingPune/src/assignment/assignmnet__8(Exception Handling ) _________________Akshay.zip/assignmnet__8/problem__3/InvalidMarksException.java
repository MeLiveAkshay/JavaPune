package assignment.assignmnet__8.problem__3;

class InvalidMarksException extends Exception {
    public InvalidMarksException(String message) {
        super(message);
    }
}
